﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GitQui.UserControls
{
    /// <summary>
    /// Interaction logic for CloneRepoPanel.xaml
    /// </summary>
    public partial class CloneRepoPanel : UserControl
    {
        public string URL
        {
            get
            {
                return UrlTextbox.Text;
            }
        }

        public string SelectedFolder
        {
            get
            {
                return LocalTextbox.Text;
            }
        }

        public event EventHandler<EventArgs> RepoClone;

        public CloneRepoPanel()
        {
            InitializeComponent();
        }

        private void CloneRepoClone_Click(object sender, RoutedEventArgs e)
        {
            RepoClone(sender, e);
        }

        private void CloneRepoPaste_Click(object sender, RoutedEventArgs e)
        {
            UrlTextbox.Paste();
        }

        private void CloneRepoSerch_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new System.Windows.Forms.FolderBrowserDialog
            {
                ShowNewFolderButton = true
            };

            System.Windows.Forms.DialogResult result = dialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                LocalTextbox.Text = dialog.SelectedPath;

                Properties.Settings.Default.CloneRepoFolder = LocalTextbox.Text;
                Properties.Settings.Default.Save();
            }
        }

        private void LocalTextbox_Loaded(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.Reload();
            LocalTextbox.Text = Properties.Settings.Default.CloneRepoFolder;
            UrlTextbox.Text = Properties.Settings.Default.CloneRepoURL;
        }

        private void UrlTextbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Properties.Settings.Default.CloneRepoURL  = UrlTextbox.Text;
            Properties.Settings.Default.Save();
        }
    }
}
