﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using GitQui.Views.Dialogs;
using GitQui.ViewModel;

namespace GitQui.Views
{
    /// <summary>
    /// Interaction logic for LogView.xaml
    /// </summary>
    public partial class LogView : Window
    {
        public LogView(RepositoryViewModel repoViewModel)
        {
            InitializeComponent();

            DataContext = repoViewModel;
        }

        private void Pull_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Push_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Commit_Click(object sender, RoutedEventArgs e)
        {
            CommitView _CommitView = new CommitView();
            _CommitView.ShowDialog();
        }

        private void CreateBranch_Click(object sender, RoutedEventArgs e)
        {
            Branch _Branch = new Branch();
            _Branch.Show();
        }

        private void CheckoutBranch_Click(object sender, RoutedEventArgs e)
        {
            Checkout _Checkout = new Checkout();
            _Checkout.Show();
        }

        private void MergeBranch_Click(object sender, RoutedEventArgs e)
        {
            Merge _Merge = new Merge();
            _Merge.Show();
        }
    }
}
