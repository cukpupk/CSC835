﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GitQui.UserControls;
using GitQui.ViewModel;

namespace GitQui.Views
{
    /// <summary>
    /// Interaction logic for RepoView.xaml
    /// </summary>
    public partial class RepoView : Window
    {
        // UserControls
        private CreateRepoPanel _CreateRepoPanel;
        private OpenRepoPanel _OpenRepoPanel;
        private CloneRepoPanel _CloneRepoPanel;

        public RepoView()
        {
            InitializeComponent();

            _CreateRepoPanel = new CreateRepoPanel();
            _OpenRepoPanel = new OpenRepoPanel();
            _CloneRepoPanel = new CloneRepoPanel();

            _CreateRepoPanel.RepoCreate += CreateRepoPanel_RepoCreate;
            _OpenRepoPanel.RepoOpen += OpenRepoPanel_RepoOpen;
            _CloneRepoPanel.RepoClone += CloneRepoPanel_RepoClone;
        }

        private void OpenRepo_Click(object sender, RoutedEventArgs e)
        {
            RepoPanel.NavigationService.Navigate(_OpenRepoPanel);
        }

        private void CreateRepo_Click(object sender, RoutedEventArgs e)
        {
            RepoPanel.NavigationService.Navigate(_CreateRepoPanel);
        }

        private void CloneRepo_Click(object sender, RoutedEventArgs e)
        {
            RepoPanel.NavigationService.Navigate(_CloneRepoPanel);
        }

        private void OpenRepoPanel_RepoOpen(object sender, EventArgs e)
        {
            string selectedFolder = _OpenRepoPanel.SelectedFolder;

            RepositoryViewModel repo = new RepositoryViewModel(selectedFolder);
            if (repo.IsInited() == true)
            {
                repo.OpenRepo();
                LogView view = new LogView(repo);
                view.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Selected folder is not git folder!");
            }
        }

        private void CreateRepoPanel_RepoCreate(object sender, EventArgs e)
        {
            string selectedFolder = _CreateRepoPanel.SelectedFolder;

            RepositoryViewModel repo = new RepositoryViewModel(selectedFolder);

            repo.InitRepo();   
            MessageBox.Show("New git repository created!");

            LogView view = new LogView(repo);
            view.Show();
            this.Close();

        }

        private void CloneRepoPanel_RepoClone(object sender, EventArgs e)
        {
            string URL = _CloneRepoPanel.URL;
            string selectedFolder = _CloneRepoPanel.SelectedFolder;
 
            RepositoryViewModel repo = new RepositoryViewModel(selectedFolder);
            if (repo.CloneRepo(URL, selectedFolder))
            {
                LogView view = new LogView(repo);
                view.Show();
                this.Close();

            }
            else
            {
                MessageBox.Show("Sorry! Something went wrong!!");
            }


        }
    }
}
