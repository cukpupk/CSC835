﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GitQui.Model
{
    public class RemoteModel
    {
        public string Name { get; set; }
        public string Path { get; set; }

    }
}
