﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GitQui.UserControls
{
    /// <summary>
    /// Interaction logic for CreateRepoPanel.xaml
    /// </summary>
    public partial class CreateRepoPanel : UserControl
    {
        public string SelectedFolder
        {
            get
            {
                return LocalTextbox.Text;
            }
        }

        public event EventHandler<EventArgs> RepoCreate;

        public CreateRepoPanel()
        {
            InitializeComponent();
        }

        private void CreateRepoCreate_Click(object sender, RoutedEventArgs e)
        {
            RepoCreate(this, EventArgs.Empty);
        }

        private void CreateRepoSerch_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new System.Windows.Forms.FolderBrowserDialog
            {
                ShowNewFolderButton = true
            };

            System.Windows.Forms.DialogResult result = dialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                LocalTextbox.Text = dialog.SelectedPath;
            }
        }
    }
}
