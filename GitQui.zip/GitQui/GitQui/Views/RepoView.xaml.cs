﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GitQui.UserControls;
using GitQui.ViewModel;

namespace GitQui.Views
{
    /// <summary>
    /// Interaction logic for RepoView.xaml
    /// </summary>
    public partial class RepoView : Window
    {
        // UserControls
        private CreateRepoPanel _CreateRepoPanel;
        private OpenRepoPanel _OpenRepoPanel;
        private CloneRepoPanel _CloneRepoPanel;

        public RepoView()
        {
            InitializeComponent();

            _CreateRepoPanel = new CreateRepoPanel();
            _OpenRepoPanel = new OpenRepoPanel();
            _CloneRepoPanel = new CloneRepoPanel();

            _CreateRepoPanel.RepoCreate += CreateRepoPanel_RepoCreate;
            _OpenRepoPanel.RepoOpen += OpenRepoPanel_RepoOpen;
            _CloneRepoPanel.RepoClone += CloneRepoPanel_RepoClone;
        }

        private void OpenRepo_Click(object sender, RoutedEventArgs e)
        {
            RepoPanel.NavigationService.Navigate(_OpenRepoPanel);
        }

        private void CreateRepo_Click(object sender, RoutedEventArgs e)
        {
            RepoPanel.NavigationService.Navigate(_CreateRepoPanel);
        }

        private void CloneRepo_Click(object sender, RoutedEventArgs e)
        {
            RepoPanel.NavigationService.Navigate(_CloneRepoPanel);
        }

        private void OpenRepoPanel_RepoOpen(object sender, EventArgs e)
        {
            string selectedFolder = _OpenRepoPanel.SelectedFolder;

            RepositoryViewModel repo = new RepositoryViewModel(selectedFolder);
            if (repo.IsInited() == true)
            {
                LogView view = new LogView(repo);
                view.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Selected folder is not git folder!");
            }
        }

        private void CreateRepoPanel_RepoCreate(object sender, EventArgs e)
        {
            string selectedFolder = _OpenRepoPanel.SelectedFolder;

            RepositoryViewModel repo = new RepositoryViewModel();

            MessageBox.Show("Repository created!");

            LogView view = new LogView(repo);
            view.Show();
            this.Close();

        }

        private void CloneRepoPanel_RepoClone(object sender, EventArgs e)
        {
//             if (repo.CloneRepo(UrlTextbox.Text, LocalTextbox.Text, dialog.returnUN(), dialog.returnPass()) == true)
//             {
//                 dialog.Close();
//                 ViewUC view = new ViewUC(LocalTextbox.Text);
//                 view.Show();
//                 this.Close();
// 
//             }
//             else
//             {
//                 System.Windows.Forms.MessageBox.Show("Ups..something went wrong!!");
//             }
        }
    }
}
